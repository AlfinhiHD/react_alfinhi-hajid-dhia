
const HeaderTitle= (props) => {
    return (
        <h1>
           {props.label} 
        </h1>

    );
}

export default HeaderTitle