

const HeaderBody= (props) => {
    return (
        <p>
            {props.label}
        </p>

    );
}

export default HeaderBody