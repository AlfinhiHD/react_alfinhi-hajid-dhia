
function ErrorPage() {

    return (
        <h1 className="m-5">Yailah salah page bang?</h1>
    )
}

export default ErrorPage